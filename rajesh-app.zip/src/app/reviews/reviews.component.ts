import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css'],
})
export class ReviewsComponent implements OnInit {
  constructor() {}

  
  ngOnInit(){

  
    $(document).ready(function(){
      $("#testimonial-slider").owlCarousel({
          items:2,
          itemsDesktop:[1000,2],
          itemsDesktopSmall:[990,2],
          itemsTablet:[768,1],
          pagination:true,
          navigation:false,
          navigationText:["",""],
          slideSpeed:1000,
          autoPlay:true,
         
         
      });
  });

  
  }

 
}
