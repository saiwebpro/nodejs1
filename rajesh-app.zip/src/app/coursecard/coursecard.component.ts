import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-coursecard',
  templateUrl: './coursecard.component.html',
  styleUrls: ['./coursecard.component.css'],
})
export class CoursecardComponent implements OnInit {
  @Input() courseObj: any;
  constructor(private router: Router) {}

  ngOnInit(): void {
    console.log('course obj in course card is ', this.courseObj);
  }

  showCourseDeatils() {
    //store courseObj in local storage temporarily and read at view course component
    localStorage.setItem('courseObj', JSON.stringify(this.courseObj));

    //redirect to view course component
    this.router.navigate(['/viewcourse']);
  }
}
