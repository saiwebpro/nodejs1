import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as AOS from 'aos';
declare var $: any;

@Component({
  selector: 'app-viewcourse',
  templateUrl: './viewcourse.component.html',
  styleUrls: ['./viewcourse.component.css'],
})
export class ViewcourseComponent implements OnInit {

  courseObj:any;
  constructor(private router:Router) {}

  ngOnInit(): void {
   
    window.scrollTo(0,0);
    AOS.init();
    //read courseObj from localstorage
    this.courseObj= JSON.parse(  localStorage.getItem("courseObj"))
    console.log("in view course ",this.courseObj)
  }

  gotoRegister(){
    this.router.navigate(['/register'])
  }
}
