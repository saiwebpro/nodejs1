import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import {LoginService} from "../login.service"

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router,private ls:LoginService) { }
  

  ngOnInit(): void {
  }

  onSubmit(ngForm:NgForm){
    let userObj=ngForm.value;
    console.log(userObj);
    this.ls.login(userObj).subscribe(

     
      res=>{
        console.log("res in logincomp ",res["message"])
        if(res["message"]=="login-success"){
          sessionStorage.setItem("token",res["jwt"]);
          this.router.navigate(["admin"])
        }
        else{
          alert(res["message"]);
          ngForm.reset();
        }
      },
      err=>{
        alert("Something went wrong..plz try again");
        console.log(err)
      }
    )
   
  }
}
