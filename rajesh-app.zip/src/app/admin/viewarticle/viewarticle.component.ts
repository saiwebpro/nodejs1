import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewarticle',
  templateUrl: './viewarticle.component.html',
  styleUrls: ['./viewarticle.component.css']
})
export class ViewarticleComponent implements OnInit {

  articlesList:any=[];
  constructor(private hc:HttpClient) { }

  ngOnInit(): void {
    this.hc.get("/articles/readall").subscribe(
      res=>{
        this.articlesList=res["message"].articles;
        console.log(this.articlesList)
      },
      err=>{
        alert("Something wrong in reading articles");
        console.log(err)
      }
    )
  }

}
