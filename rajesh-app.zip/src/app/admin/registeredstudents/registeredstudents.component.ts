import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../admin.service';
@Component({
  selector: 'app-registered-students',
  templateUrl: './registeredstudents.component.html',
  styleUrls: ['./registeredstudents.component.css'],
})
export class RegisteredStudentsComponent implements OnInit {
  registeredUsers: any[] = [];
  searchTerm:string;
  searchOption:string;
  constructor(private adminService: AdminService) {}

  editFormView: boolean = false;
  userObjectToEdit: any;

  selectButtonView: boolean = false;
  statusvalues: string[] = ['registered', 'joined', 'completed', 'ignored'];

  ngOnInit(): void {
    this.adminService.getRegisteredSTudentData().subscribe(
      (res) => {
        if (res.length == 0) {
          alert('No users regisered yet');
        } else {
          console.log(res);
          this.registeredUsers = res;
        }
      },
      (err) => {}
    );
  }

  showEditForm(user) {
    this.editFormView = true;
    this.userObjectToEdit = user;
  }
  onEditAndSave() {
    this.editFormView = false;
  }

  id: any;
  showSelectButton(id) {
    this.selectButtonView = true;
    console.log(id);
    this.id = id;
  }

  getNewStatus(id, event, index) {
    console.log('status chaged to id ', id);
    console.log('value is ', event.target.value);

    this.adminService.updateUserStatus(id, event.target.value).subscribe(
      (res) => {
        console.log(res['message']);
        this.registeredUsers[index] = res['message'];
        this.selectButtonView = false;
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
