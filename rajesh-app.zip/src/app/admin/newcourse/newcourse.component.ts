import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {
  FormBuilder,
  FormGroup,
  FormArray,
  AbstractControl,
} from '@angular/forms';
import { Router } from '@angular/router';
import { CourseService } from 'src/app/course.service';

@Component({
  selector: 'app-newcourse',
  templateUrl: './newcourse.component.html',
  styleUrls: ['./newcourse.component.css'],
})
export class NewcourseComponent implements OnInit {
  // coursetitle: string;
  // title:string;
  // version:string;
  // courseduration:string;
  // coursedescription:string;
  // courseicon:string;
  // prerequicite:string;
  // articlelinks:string;
  // topic: string;
  // subcontent: string;

  ngOnInit() {
    sessionStorage.clear();
  }

  public form: {
    topics: Topic[];
  };

  // I initialize the app component.
  constructor(private router: Router, private courseService: CourseService) {
    this.form = {
      topics: [],
    };

    // Add an initial pet form-entry.
    this.addTopic();
  }

  // I add a new pet record to the form-model.
  public addTopic(): void {
    // CAUTION: When we output the form controls, we need to provide a unique name
    // for each input (so that it can be registered with the parent NgForm). For the
    // sake of this demo, we're going to use the current TIMPESTAMP (Date.now()) as a
    // hook into something unique about this model.
    this.form.topics.push({
      id: Date.now(), // <--- uniqueness hook.
      topic: '',
      subcontent: '',
    });
  }

  // I process the form-model.
  public processForm(form: any): void {
    // console.log(form.value)
    let courseObject: object = {};
    // courseObject["coursetitle"]=form.value.coursetitle;
    // courseObject["title"]=form.value.title;
    // courseObject["version"]=form.value.version;
    // courseObject["courseduration"]=form.value.courseduration;
    // courseObject["coursedescription"]=form.value.coursedescription;
    // courseObject["courseicon"]=form.value.courseicon;
    // courseObject["prerequicite"]=form.value.prerequicite;
    // courseObject["articlelinks"]=form.value.articlelinks;
    // courseObject["coursecontent"]=this.newTopics;

    courseObject['coursetitle'] = form.coursetitle;
    courseObject['title'] = form.title;
    courseObject['version'] = form.version;
    courseObject['courseduration'] = form.courseduration;
    courseObject['coursedescription'] = form.coursedescription;
    courseObject['courseicon'] = form.courseicon;
    courseObject['prerequicite'] = form.prerequicite;
    courseObject['articlelinks'] = form.articlelinks;
    courseObject['coursecontent'] = this.newTopics;

    console.log('course object is ', courseObject);
    this.courseService.saveNewCourse(courseObject).subscribe(
      (res) => {
        alert(res['message']);
      },
      (err) => {
        alert('Something went wrong in creating new course...Please try again');
      }
    );

    //  console.groupEnd();

    //  console.group('Form Model');
    // console.log(form);
    //   console.groupEnd();
  }

  // I remove the pet at the given index.
  public removeTopic(index: number): void {
    this.form.topics.splice(index, 1);
  }

  newTopics: object[] = [];
  getTopicAndSubcontent(ref1, ref2) {
    let obj = {};
    obj['topic'] = ref1.value;
    obj['subcontent'] = ref2.value.split('/');
    this.newTopics.push(obj);
  }
}

interface Course {
  id: number;
  title: string;
  version: string;
  courseduration: string;
  coursedescription: string;
  courseicon: string;
  prerequicite: string;
  articlelinks: string;
  topic: string;
  subcontent: string;
}

interface Topic {
  id: number;
  topic: string;
  subcontent: string;
}
