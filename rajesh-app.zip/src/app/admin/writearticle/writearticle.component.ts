import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-writearticle',
  templateUrl: './writearticle.component.html',
  styleUrls: ['./writearticle.component.css']
})
export class WritearticleComponent implements OnInit {

  newarticle:string;

  constructor(private hc:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }

  addNewArticle(ref:NgForm){
    
   let articleObj=ref.value;
    this.hc.post("articles/addnew",articleObj).subscribe(
      res=>{
        if(res["message"]==="success"){
          alert("New article added successfully")
          this.router.navigate(["./admin/viewarticle"]);
        }
      },
      err=>{
        alert("something went wrong in adding article");
        console.log(err)
      }
    )

  }
}
