import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css'],
})
export class NotificationsComponent implements OnInit {

  newnotification:string;
  notifications:any[]=[]
  constructor(private httpClient:HttpClient) {}

  ngOnInit(): void {

    this.httpClient.get("admin/getnotifications").subscribe(
      res=>{
        this.notifications=res["message"];
      },
      err=>{
        alert("Something went wrong..We will fix it soon")
      }
    )
  }

  saveNewNotification(){
      console.log(this.newnotification);
      let notificationObj={notification:this.newnotification};
      this.httpClient.post("/admin/savenotification",notificationObj).subscribe(
        res=>{
          this.notifications=res["message"]
        },
        err=>{
          alert("Something went wrong..Please try again")
          console.log(err);
        }
      )
      this.newnotification=""
      
  }

  removeNotifications(id){
      this.httpClient.delete(`/admin/removenotification/${id}`).subscribe(
        res=>{
          console.log("after remove ",res["message"])
          this.notifications=res["message"]
        },
        err=>{
          alert("Something went wrong..Please try again")
          console.log(err)
        }
      )
  }
}
