import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private httpClient: HttpClient) {}
  getRegisteredSTudentData(): Observable<any[]> {
    return this.httpClient.get<any[]>('/admin/registeredusers');
  }
  updateUserStatus(userid, newstatus): Observable<any[]> {
    let tempUserObj = { _id: userid, currentstatus: newstatus };

    console.log(tempUserObj,"  ",newstatus)
    return this.httpClient.put<any[]>('/admin/updateuserstatus', tempUserObj);
  }
}
