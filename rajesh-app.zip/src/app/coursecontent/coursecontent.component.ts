import { Component, OnInit } from '@angular/core';
import * as AOS from 'aos';

@Component({
  selector: 'app-coursecontent',
  templateUrl: './coursecontent.component.html',
  styleUrls: ['./coursecontent.component.css'],
})
export class CoursecontentComponent implements OnInit {
  //courseObj
  courseObj: any;

  constructor() {}

  ngOnInit(): void {
    AOS.init();
    this.courseObj = JSON.parse(localStorage.getItem('courseObj'));
  }
}
