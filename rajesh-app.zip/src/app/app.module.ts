import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HeaderComponent } from './header/header.component';
import { FounderComponent } from './founder/founder.component';
import { CoursecardComponent } from './coursecard/coursecard.component';
import { CoursesComponent } from './courses/courses.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CoursecontentComponent } from './coursecontent/coursecontent.component';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import { FooterComponent } from './footer/footer.component';

import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AdminRoutingModule } from './admin/admin-routing.module';
import { SearchPipe } from './search.pipe';
import { ReviewsComponent } from './reviews/reviews.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HeaderComponent,
    FounderComponent,
    CoursecardComponent,
    CoursesComponent,
    CoursecontentComponent,
    ViewcourseComponent,
    FooterComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    ReviewsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FlexLayoutModule,
    FormsModule,
    HttpClientModule,
    AdminRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
