import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search',
})
export class SearchPipe implements PipeTransform {
  transform(data: any[], ...searchTerm: string[]): any {
    console.log('search term is ', searchTerm);
    if (!data || !searchTerm[0] || !searchTerm[1]) {
      return data;
    } else {
      return data.filter((user) => {
        if (searchTerm[1] == 'name') {
          return (
            user.firstname
              .toLowerCase()
              .indexOf(searchTerm[0].toLowerCase()) !== -1
          );
        } else if (searchTerm[1] == 'coursetitle') {
          return (
            user.coursetitle
              .toLowerCase()
              .indexOf(searchTerm[0].toLowerCase()) !== -1
          );
        } else if (searchTerm[1] == 'phone') {
          return user.phone.indexOf(searchTerm[0]) !== -1;
        } else if (searchTerm[1] == 'newstatus') {
          return (
            user.newstatus
              .toLowerCase()
              .indexOf(searchTerm[0].toLowerCase()) !== -1
          );
        } else if (searchTerm[1] == 'email') {
          return (
            user.email.toLowerCase().indexOf(searchTerm[0].toLowerCase()) !== -1
          );
        }
      });
    }
  }
}
