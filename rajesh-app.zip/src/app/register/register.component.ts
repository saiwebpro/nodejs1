import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
declare var $: any;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  allcoursesObj: any = {};
  coursesArray: any[] = [];
  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    // sessionStorage.clear();
    this.allcoursesObj = JSON.parse(localStorage.getItem('allcourses'));
    this.coursesArray = this.allcoursesObj['courses'];
    console.log('course array ', this.coursesArray);
  }

  message: string;

  onRegister(formObj: NgForm) {
    let userObj = formObj.value;
    console.log(userObj);
    this.userService.register(userObj).subscribe(
      (res) => {
        console.log(res['message']);
        //success
        if (res['status'] === 'success') {
          this.message = res['message'];
          $('document').ready(function () {
            $('#overlaysuccess').modal('show');
          });
        }

        //failed
        if (res['status'] === 'failed') {
          this.message = res['message'];
          $('document').ready(function () {
            $('#overlayfailed').modal('show');
          });

          // setTimeout(function () {
          //   $('#overlayfailed').modal('hide');

          // }, 4000);
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  closeFailModal() {
    $('#overlayfailed').modal('hide');
    this.router.navigateByUrl('/home');
  }

  closeSuccessModal(){
    $('#overlaysuccess').modal('hide');
    this.router.navigateByUrl('/home');
  }
}
