import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor(private hc: HttpClient, private router: Router) {}

  login(userObj): Observable<any> {
    return this.hc.post('admin/login', userObj);
  }
  logout() {
    sessionStorage.removeItem('token');
    this.router.navigateByUrl('/home');
  }
}
