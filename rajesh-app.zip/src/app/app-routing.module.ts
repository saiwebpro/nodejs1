import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import {HomeComponent} from './home/home.component';
import {RegisterComponent} from './register/register.component'
import { LoginComponent } from './login/login.component';
import { ViewarticleComponent } from './admin/viewarticle/viewarticle.component';

const routes: Routes = [
  {path:"home",component:HomeComponent},
  {path:"register",component:RegisterComponent},
  {path:"viewcourse",component:ViewcourseComponent},
  {path:"login",component:LoginComponent},
  {path:"viewarticles",component:ViewarticleComponent},
 
  {
    path: 'admindashboard',
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)
  },
  {path:"",redirectTo:"home",pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
