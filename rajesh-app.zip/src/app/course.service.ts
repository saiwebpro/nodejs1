import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CourseService {

  //inject HttpClient module
  constructor(private httpClient:HttpClient) {}

  //make HTTP GET req to get courses object
  getCourses():Observable<object>{
    return this.httpClient.get<object>("/courses/readall");
  }

  saveNewCourse(newCourseObject):Observable<any>{

    console.log("course obj in service ",newCourseObject)
    return this.httpClient.post("/courses/save",newCourseObject);
  }
}
